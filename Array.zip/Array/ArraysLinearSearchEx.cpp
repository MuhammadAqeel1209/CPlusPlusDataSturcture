#include<iostream>
using namespace std;

// Linear Search: Particular element is available or not
bool Search(const int array[], int size, int key)
{
	bool flag = false;
	for(int i=0; i<size; i++)
	{
		if(array[i] == key)
			flag = true;
	}
	
	return flag;
}

int bubbleSort(int array[], int size)
{
	int passes = 0;
	for(int i=0; i<size-1; i++)
	{
		for(int j=0; j<size-1; j++)
		{
			if(array[j] < array[j+1])	// array[0] < array[1]
			{
				int temp = array[j];
				array[j] = array[j+1];
				array[j+1] = temp;
			}
		}
		passes++;
	}
	
	return passes;
}

int main()
{
	const int SIZE = 10;
	int array[SIZE] = {19, 50, 120, 40, 40, 60, 70, 100, 90, 800};
	
	int pass = bubbleSort(array, SIZE);
	
	for(int i=0; i<SIZE; i++)
	{
		cout << array[i] << "\t";
	}
	
	cout << "Total Passes Executed " << pass << endl;
	
	int element = 0;
	
	cout << "Enter Element to Search:\t";
	cin >> element;
	
	bool flag = Search(array, SIZE, element);
	
if(flag == 1)
		cout << element << " is found" << endl;
	else
		cout << element << " could not be found!!!" << endl;
	
}
