#include<iostream>

using namespace std;

/***************************** Radio Class *****************************/
class Radio
{
	private:
		string channel;
		int frequency;
		
	public:
		Radio()
		{
			
		}
		Radio(string theChannel, int theFreq)
		{
			channel = theChannel;
			frequency = theFreq;
		}
		
		string getChannel()
		{
			return channel;
		}
		
		int getFrequency()
		{
			return frequency;
		}
		
		void setChannel(string data)
		{
			channel = data;
		}
		
		void setFrequency(int data)
		{
			frequency = data;
		}
		void print()
		{
			cout << "RADIO INFORMATION" << endl;
			cout << "-----------------" << endl;
			cout << "CHANNEL:\t" << channel << endl;
			cout << "FREQUENCY:\t" << frequency << endl;
		}
};


/***************************** Main function *****************************/
int main()
{
	Radio array[3];
	string channel;
	int freq;
	
	for(int i=0; i<3; i++)
	{
		cout << "Enter Channel:\t";\
		cin >> channel;
		array[i].setChannel(channel);
		cout << "Enter Frequency:\t";
		cin >> freq;
		array[i].setFrequency(freq);
	}
	
	for(int i=0; i<3; i++)
	{
		array[i].print();
	}	
}







