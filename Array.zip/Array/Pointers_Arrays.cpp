#include<iostream>

using namespace std;

int main()
{
	char source [20] = {"This is a test"};
	char dest [20] ; 
	
	char *srcPtr;
	char *destPtr;
	
	srcPtr = source;
	destPtr = dest;
	
	
	while(*srcPtr != '\0')
	{
		*destPtr = *srcPtr;
		destPtr++;
		srcPtr++;
	}
	*destPtr = '\0';
	
	cout << "SOURCE:\t" << source << endl;
	cout << "DESTINATION:\t" << dest << endl;
	
	
}
