#include<iostream>
using namespace std;

/*
	1. To Copy Arrays:
		1.1 Datatype same
		1.2 Size
	2. Arrays as an argument
		2.1 Complete array is passed as reference (datatype name, size)
		2.2	Single element of array is passed as value
*/

void squaredArray(int array[], int size)
{
	for(int i=0; i<size; i++)
	{
		array[i] = array[i] * array[i];
	}
}

void printArray(int array[], int size)
{
	for(int k=0; k<size; k++)
	{
		cout << array[k] << endl;
	}
}

int test(int number)
{
	number = number * number * number;
	return number;
}

int main()
{
	int myArray[5] = {10, 20, 30, 40, 50};	// 20 X 20 = 400
	cout << test(myArray[1]) << endl;
	
	printArray(myArray, 5);


	// cout << "BEFORE FUNCTION CALLING" << endl;
	// cout << "-----------------------" << endl;
	
	// printArray(myArray, 5);
	
	// squaredArray(myArray, 5);
	
	// cout << "AFTER FUNCTION CALLING" << endl;
	// cout << "-----------------------" << endl;
	// printArray(myArray, 5);


// const int ARRAYSIZE = 10;
//	int source[ARRAYSIZE] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
//	int destination[ARRAYSIZE];
//	
//	for(int k=0; k<ARRAYSIZE; k++)
//	{
//		destination[k] = source[k];
//	}
//		
//	cout << "SOURCE\tDESTINATION" << endl;
//	cout << "------\t-----------" << endl;
//	
//	for(int i=0; i<ARRAYSIZE; i++)
//	{
//		cout << source[i] << "\t" << destination[i] << endl;
//	}


//	const int SIZE = 10;
//	int array[SIZE] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//	int sumOfSquares = 0;
//	
//	for(int i=0; i<SIZE; i++)
//	{
//		array[i] = array[i] * array[i];	// array[0] = array[0] * array[0]
//		sumOfSquares = sumOfSquares + array[i];
//	}
//	
//	
//	cout << "Sum of Squared is " << sumOfSquares << endl;
}