#include<iostream>
using namespace std;

int main()
{
	// Singleular Array
	// Multi-dimensional
	const int SIZE = 5;
	float marks[SIZE];
	
	for(int i=0; i<SIZE; i++)
	{
		cout << "Enter Marks\t";
		cin >> marks[i];	//marks[..]
	}
	
	cout << "Marks[3]\t" << marks[3] << endl;
	
	for(int j=0; j<SIZE; j++)
	{
		cout << "Marks[" << j << "]\t" << marks[j] << endl;
	}
	
	
}
