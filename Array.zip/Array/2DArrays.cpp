#include<iostream>

using namespace std;

int main()
{
	const int rows = 3;
	const int columns = 3;
	
	int array[rows][columns];
	
	for(int i=0; i<rows; i++)
	{
		for(int j=0; j<columns; j++)
		{
			cout << "Enter Array Elements for "; // << array[i][j];
			cin >> array[i][j];
		}
	}
	
	for(int k=0; k<rows; k++)
	{
		for(int m=0; m<columns; m++)
		{
			cout << array[k][m] << "\t";
		}
		cout << endl;
	}
}
