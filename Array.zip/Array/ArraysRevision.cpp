#include<iostream>

using namespace std;

void getInput(int array[], int size)
{
	// Iterate Over for input
	for(int i=0; i<size; i++)
	{
		cout << "Enter Marks for Student 1:\t";
		cin >> array[i];
	}
}

int getSum(int array[], int size)
{
	int sum = 0;
	for(int j=0; j<size; j++)
	{
		sum = sum + array[j];
	}

	return sum;
}

void averageMarks(int sum, int size)
{
	// average to calculate for 50 students
	cout << "Average Marks = " << sum/size << endl;
}

int main()
{
	const int SIZE = 5;
	int marks[SIZE]; float average = 0; int sum = 0;

	getInput(marks, SIZE);
	sum = getSum(marks, SIZE);

	averageMarks(sum, SIZE) ;
}
