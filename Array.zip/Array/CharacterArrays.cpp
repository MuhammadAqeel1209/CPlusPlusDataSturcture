#include<iostream>
using namespace std;

// The functions will operate on integere types
// Challenge: Modify these functions so that they an operate on character data types
void inputArray(char array[], int size)
{
	for(int i=0; i<size; i++)
	{
		cout << "Enter Data:\t";
		cin >> array[i];
	}
}

void printArray(char array[], int size)
{
	for(int i=0; i<size; i++)
	{
		cout << array[i] << "\t";
	}
	cout << endl;
}

bool compareArrays(char source[], char destination[], int size)
{
	bool flag = false;
	for(int i=0; i<size; i++)
	{
		if(source[i] != destination[i])
		{
			flag = false;
			break;
		}
		
		flag = true;
	}
	
	return flag;
}

int main()
{
	// 1. Data types of both arrays must be similar int array[] --> int second[]
	// 2. Size of both the arrays must be similar a[10] --> b[10];
	// Shahid == Zahid
	const int SIZE = 5;
	char source[SIZE];
	char destinatin[SIZE];
	bool flag = false;
	
	inputArray(source, SIZE);
	inputArray(destinatin, SIZE);
	
	cout << "---------------------------------------\n";
	printArray(source, SIZE);
	printArray(destinatin, SIZE);
	cout << "---------------------------------------\n";
	
	flag = compareArrays(source, destinatin, SIZE);
	
	if(flag)	// flag == true
	{
		cout << "Both the arrays are equal" << endl;
	}
	else
	{
		cout << "Both the arrays are NOT equal" << endl;
	}
}






	/*
	char firstName[100];	// '\0'
	int counter = 0;
	char secondName[100] = "Musa Shahid\0"; --> \0 == Enter Key
	// Department of Computer Science --> 
		
	cout << "Enter Yor Name:\t";
	gets(firstName);
	
	for(int i=0; firstName[i]!=0; i++)
	{
		counter++;
		cout << firstName[i];
	}
	
	cout << "The name '" << firstName << "' contains " << counter << " characters" << endl;
	*/
