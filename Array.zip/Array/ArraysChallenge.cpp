#include<iostream>

using namespace std;

void inputArray(int array[], int size)
{
	for(int i=0; i<size; i++)
	{
		cout << "Enter Array Elements:\t";
		cin >> array[i];
	}

}

bool compareArrays(int firstArray[], int secondArray[], int size)
{
	bool flag = false;
	for(int i=0; i<size; i++)
	{
		if(firstArray[i] != secondArray[i])
		{
			flag = false;
		}
		else
			flag = true;
	}
	
	return flag;
}
int main()
{
	int first[5];
	int second[6];
	
	inputArray(first, 5);
	cout << "\nnext array" << endl;
	inputArray(second, 5);
	
	bool flag = compareArrays(first, second, 5);
	
	cout << "\nTHE RESULT AFTER COMPARE THE ARRAY IS::\t";
	if(flag == true)
	{
		cout << "BOTH ARRAYS ARE EQUAL" << endl;
	}
	else
	{
		cout << "BOTH ARRAYS ARE NOT EQUAL" << endl;
	}
}
