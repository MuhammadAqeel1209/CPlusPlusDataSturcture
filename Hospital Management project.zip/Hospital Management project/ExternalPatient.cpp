#include<iostream>
using namespace std;

class EPatient
{
    public:
    int appointment_no;
    string patient_name;
    int age;
    string disease;
    EPatient(){}
    EPatient(int appointment_no, string patient_name, int age,string disease)
    {
        this->appointment_no = appointment_no;
        this->patient_name = patient_name;
        this->age = age;
        this->disease = disease;
    }

    void SetAppointmentNo(int appointment_no)
    {
        appointment_no = this->appointment_no;
    }

    void SetPaitentName(string name)
    {
        name = this->patient_name;
    }

    void SetAge(int age)
    {
        age = this->age;
    }

    void SetDisease(string disease)
    {
        disease = this->disease;
    }

};