#include <iostream>
#include <windows.h>
#include "patient.cpp"
#include "Doctor.cpp"
#include "ExternalPatient.cpp"
#include <queue>
#include <fstream>
using namespace std;

class Hospital
{
private:
    Patient data;
    Doctors doctorData;
    Hospital *leftNode;
    Hospital *rightNode;
    string doctor_day;

public:
    Hospital()
    {
    }
    // constructor -->parameters-->doctors and class parameters
    Hospital(Patient data, Doctors doctorData)
    {
        this->data = data;
        this->doctorData = doctorData;
        leftNode = NULL;
        rightNode = NULL;
    }
    void setDoctorDay(string doctor_day)
    {
        this->doctor_day = doctor_day;
    }
    string getDoctorDay()
    {
        return doctor_day;
    }
    // FUnctions for adding the patient
    void Addpatients(Doctors doctorData, Patient data)
    {
        if (doctorData.GetDoctorId() < this->doctorData.GetDoctorId())
        {
            leftNode->Addpatients(doctorData, data);
        }
        if (doctorData.GetDoctorId() < this->doctorData.GetDoctorId())
        {
            rightNode->Addpatients(doctorData, data);
        }
    }
    // Function for dataing height
    int height(Hospital *node)
    {
        int xheight, yheight;
        if (node == NULL)
            return 0;
        else if (node != NULL)
        {
            xheight = height(node->leftNode);
            yheight = height(node->rightNode);
            if (xheight > yheight)
                return xheight + 1;
            else
                return yheight + 1;
        }
        else
            return -1;
    }

    bool GetData(string name)
    {
        ifstream inputFile("HospitalManagementSystem.txt");
        if (!inputFile)
        {
            cout << "Failed to open the file." << endl;
    }

        string searchTerm = name;
        string line;
        while (getline(inputFile, line)) 
        {
            if (line.find(searchTerm) != string::npos)
            {
                return true;
            }
        }

    inputFile.close();
    return false;

    }

    bool searchNode(Hospital *root, string name)
    {
        if (root == NULL)
            return false;
        else if (name == root->data.GetPaitentName())
            return true;
        else if (name < root->data.GetPaitentName())
            return GetData(name);
        else if (name > root->data.GetPaitentName())
            return GetData(name);
        else
            return false;
    }

    Hospital *predecessor(Hospital *root)
    {
        while (root && root->rightNode != NULL)
            root = root->rightNode;
        return root;
    }
    Hospital *Succesor(Hospital *root)
    {
        while (root && root->leftNode != NULL)
            root = root->leftNode;
        return root;
    }
    Hospital *DeleteNode(Hospital *root, int key)
    {
        Hospital *tempPtr;
        // if root is empty or there is no node in the
        if (root == NULL)
            return NULL;
        // deleting leaf node
        if (root->leftNode == NULL && root->rightNode == NULL)
        {
            if(key == root->data.GetPaitentId())
            {
                root = NULL;
                delete root;
                return NULL;
            }
        }
        // first search and than delete
        if (key < root->data.GetPaitentId())
            root->leftNode = DeleteNode(root->leftNode, key);
        else if (key > root->data.GetPaitentId())
            root->rightNode = DeleteNode(root->rightNode, key);
        else
        {
            if (height(root->leftNode) > height(root->rightNode))
            {
                tempPtr = predecessor(root->leftNode);
                root->data = tempPtr->data;
                root->leftNode = DeleteNode(root->leftNode, tempPtr->data.GetPaitentId());
            }
            else
            {

                tempPtr = Succesor(root->rightNode);
                root->data = tempPtr->data;
                root->rightNode = DeleteNode(root->rightNode, tempPtr->data.GetPaitentId());
            }
        }
        return root;
    }

    void deleteDataFromFile(Hospital * root,int val)
    {
        ofstream outputFile;
        outputFile.open("HospitalManagementSystem.txt");
        if (!outputFile)
        {
            cout << "Failed to open the file." << endl;
            return;
        }
        outputFile.close();

        cout << "Data deleted from the file." << endl;
}


    // function to printing the record of patient
    void inorder_display()
    {
        ifstream inputData;
        string data;
        inputData.open("HospitalManagementSystem.txt", ios::in);
        if (!inputData)
        {
            cout << "Error in the name of file " << endl;
        }
        else
        {
            cout << "Doctor id\tDoctor Name\tDoctor Specialization\t";
            cout << "Paitent id\tPaitent Name\tPaitent Age\tPaitent Disease" << endl;
            while (!inputData.eof())
            {
                getline(inputData, data);
                cout << data;
                cout << endl;
            }
        }
        inputData.close();
    }
};
void Welcome()
{

    system("cls");
    cout << "\n\n\n\n\n\n\n\n"
         << endl;
    cout << "\t\t\t\t\t\t*******************************************************************" << endl;
    cout << "\t\t\t\t\t\t*******************************************************************" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t   WELCOME TO\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t    HOSPITAL MANAGEMENT SYSTEM\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t***\t\t\t\t\t\t\t\t***" << endl;
    cout << "\t\t\t\t\t\t*******************************************************************" << endl;
    cout << "\t\t\t\t\t\t*******************************************************************" << endl;
    cout << "\n\n";
    system("pause");
}
void AppointmentDisplay()
{
    ifstream input;
    input.open("DayByDayAppointment", ios::in);
    string data;
    if (!input)
    {
        cout << "Error in the file name " << endl;
    }
    else
    {
        while (!input.eof())
        {
            getline(input, data);
            cout << data;
            cout << endl;
        }
    }
    input.close();
}
void Choice()
{
    cout << "Enter 1 for Inserting Pateint Data " << endl;
    cout << "Enter 2 for Deleting Pateint Data " << endl;
    cout << "Enter 3 for Displaying Pateint Data " << endl;
    cout << "Enter 4 for Seaching the Pateint Data " << endl;
    cout << "Enter 5 for exit " << endl;
}

void InputExternalPaitent(int appointmentNo, string patientName, int PatientAge, string patientDisease, queue<EPatient> PatientQueue, ofstream &output)
{

    cout << "Enter the appointment no\t";
    cin >> appointmentNo;

    cout << "Enter the paitent name \t";
    cin >> patientName;

    cout << "Enter the paitent age\t";
    cin >> PatientAge;

    cout << "Enter the paitent diseases\t";
    cin >> patientDisease;

    EPatient obj1(appointmentNo, patientName, PatientAge, patientDisease);
    PatientQueue.push(obj1);
    // cout << PatientQueue.front().patient_name << "\t" << PatientQueue.front().age << "\t" << PatientQueue.front().disease << "\n";
    output << "\n\nAppointment No\tPaitent Name\tPaitentAge\tPaitentDisease" << endl;
    output << obj1.appointment_no << "\t\t" << obj1.patient_name << "\t\t" << obj1.age << "\t\t" << obj1.disease << endl;
    PatientQueue.pop(); // after appointment patient remove
}


int main()
{
    system("Color F2");
    Welcome();
    int choiceForAction;
    int SIZE = 2;
    Doctors doctorData;
    int appointmentNo;
    Patient paitentData;
    int doctorId;
    string doctorName;
    string speciliazation;
    int patientID;
    string patientName;
    int PatientAge;
    string patientDisease;
    Hospital h1;

    while (true)
    {
        cout << "\n-----------------------------------------------\n";
        cout << "[+] Write 'internal' for patient Admissions" << endl;
        cout << "[+] Write 'external' for Doctors Appointment" << endl;
        cout << "[-] Write 'exit' from hospital" << endl;
        cout << "\n-----------------------------------------------\n";
        string choose_patient;
        cout << "\n [+] Enter Patient Status for Hospital:\t";
        cin >> choose_patient;
        if (choose_patient == "internal")
        {
            Choice();
            cin >> choiceForAction;
            if (choiceForAction == 1)
            {
                for (int i = 0; i < SIZE; i++)
                {
                    cout << "--------------------------------------------------\n";
                    cout << "Enter the Doctor id\t";
                    cin >> doctorId;
                    doctorData.SetDoctorId(doctorId);

                    cout << "Enter the Doctor Name\t";
                    cin >> doctorName;
                    doctorData.SetDoctorName(doctorName);

                    cout << "Enter the Doctor Specialization\t";
                    cin >> speciliazation;
                    doctorData.SetSpecialization(speciliazation);

                    cout << "Enter the paitent id\t";
                    cin >> patientID;
                    paitentData.SetPaitentId(patientID);

                    cout << "Enter the paitent name\t";
                    cin >> patientName;
                    paitentData.SetPaitentName(patientName);

                    cout << "Enter the paitent age\t";
                    cin >> PatientAge;
                    paitentData.SetPaitentAge(PatientAge);

                    cout << "Enter the paitent diseases\t";
                    cin >> patientDisease;
                    paitentData.SetPaitentDisease(patientDisease);

                    cout << "--------------------------------------------------\n\n";

                    h1.Addpatients(doctorData, paitentData);
                    ofstream outputData;
                    outputData.open("HospitalManagementSystem.txt", ios::app);
                    outputData << doctorId << "\t\t" << doctorName << "\t\t" << speciliazation << "\t\t\t\t";
                    outputData << patientID << "\t\t" << patientName << "\t\t" << PatientAge << "\t\t" << patientDisease << "\t" << endl;
                    outputData.close();
                }
                cout << "Pateint and Doctor added " << endl;
            }
            else if (choiceForAction == 2)
            {
                int deleteId;
                cout << "Enter patient Id for Removing Patient " << endl;
                cin >> deleteId;
                cout << "\n--------------Removing the patient---------------------\n";
                h1.deleteDataFromFile(&h1, deleteId);
                h1.inorder_display();
            }

            else if (choiceForAction == 3)
            {

                h1.inorder_display();
            }
            else if (choiceForAction == 4)
            {
                system("color F4");
                string SearchbyName;
                cout << "Enter name for search:\t";
                cin >> SearchbyName;
                if(h1.searchNode(&h1, SearchbyName))
                    cout << "Exist" << endl;
                else
                    cout << "Not Exist " << endl;    
            }

            else if (choiceForAction == 5)
            {
                cout << "Thanks for visiting the Hospital:\n";
                break;
            }

            else
            {
                cout << "Invalid ";
            }
        }
        // cout << "\n--------------------------------------------\n";

        else if (choose_patient == "external")
        {
            queue<EPatient> PatientQueue;
            string day;
            cout << "Enter day to check the doctor is available or not :\n1)monday\t2)tuesday\t3)wednesday\t4)thursday\t5)friday\t6)saturday\t7)sunday\t\t";
            cin >> day;
            ofstream output;
            output.open("DayByDayAppointment", ios::app);
            Hospital epatient;
            if (day == "monday")
            {
                epatient.setDoctorDay("heart");
                output << "\n\nToday is Monday \t";
                output << "There is day of " << epatient.getDoctorDay() << " Specialist\n";
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "tuesday")
            {

                epatient.setDoctorDay("Physio_therpist");
                output << "\n\nToday is Tuesday \t";
                output << "There is day of " << epatient.getDoctorDay() << endl;
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "wednesday")
            {

                epatient.setDoctorDay("Kidney_Specailist");
                output << "\n\nToday is Wednesday \t";
                output << "There is day of " << epatient.getDoctorDay() << endl;
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "thursday")
            {

                epatient.setDoctorDay("Neurologist");
                output << "\n\nToday is Thursday \t";
                output << "There is day of " << epatient.getDoctorDay() << endl;
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "friday")
            {

                epatient.setDoctorDay("Neurologist");
                output << "\n\nToday is Friday\t";
                output << "There is day of " << epatient.getDoctorDay() << " Specialist\n";
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "saturday")
            {

                epatient.setDoctorDay("ENT_Specailist");
                output << "\n\nToday is Saturday \t";
                output << "There is day of " << epatient.getDoctorDay() << " Specialist\n";
                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
                // Object creation 2

                cout << "\n\nEnter the Second Paitent Appointment\n\n";

                InputExternalPaitent(appointmentNo, patientName, PatientAge, patientDisease, PatientQueue, output);
            }
            else if (day == "sunday")
            {
                output << "\n\nToday is Sunday \t";
                output << "Todays is Public Holiday----:\n";
            }
            else
                cout << "\n Invalid input:\n";
            output.close();
            AppointmentDisplay();
        }
        else if (choose_patient == "exit")
        {
            cout << "Thanks for visiting the Hospital:\t";
            break;
        }
        else
        {
            cout << "Invalid choice:\n";
        }
    } // while loop end
}